// components/Expenses.js
import React from 'react';
import ExpenseItem from './ExpenseItem';
import './Expenses.css';

const Expenses = (props) => {
  const removeExpenseHandler = (expenseId) => {
    props.onRemoveExpense(expenseId);
  };

  const editExpenseHandler = (updatedExpense) => {
    props.onEditExpense(updatedExpense);
  };

  return (
    <div className="expenses">
      <h2>Expenses</h2>
      {props.items.length === 0 ? (
        <p>No expenses found.</p>
      ) : (
        <ul>
          {props.items.map((expense) => (
            <ExpenseItem
              key={expense.id}
              id={expense.id}
              title={expense.title}
              amount={expense.amount}
              date={expense.date}
              onRemoveExpense={removeExpenseHandler}
              onEditExpense={editExpenseHandler}
            />
          ))}
        </ul>
      )}
    </div>
  );
};

export default Expenses;
