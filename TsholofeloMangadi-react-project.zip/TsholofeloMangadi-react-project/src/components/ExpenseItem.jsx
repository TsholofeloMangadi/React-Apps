// components/ExpenseItem.js
import React, { useState } from 'react';
import './ExpenseItem.css';

const ExpenseItem = (props) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editedTitle, setEditedTitle] = useState(props.title);
  const [editedAmount, setEditedAmount] = useState(props.amount);

  const startEditingHandler = () => {
    setIsEditing(true);
  };

  const stopEditingHandler = () => {
    setIsEditing(false);
  };

  const titleChangeHandler = (event) => {
    setEditedTitle(event.target.value);
  };

  const amountChangeHandler = (event) => {
    setEditedAmount(event.target.value);
  };

  const saveChangesHandler = () => {
    const updatedExpense = {
      id: props.id,
      title: editedTitle,
      amount: +editedAmount,
      date: props.date,
    };

    props.onEditExpense(updatedExpense);
    setIsEditing(false);
  };

  return (
    <li className="expense-item">
      {isEditing ? (
        <div>
          <input type="text" value={editedTitle} onChange={titleChangeHandler} />
          <input type="number" value={editedAmount} onChange={amountChangeHandler} />
          <button onClick={saveChangesHandler}>Save</button>
          <button onClick={stopEditingHandler}>Cancel</button>
        </div>
      ) : (
        <div>
          <h3>{props.title}</h3>
          <div className="expense-item__price">R{props.amount}</div>
          <div className="expense-item__date">{props.date.toLocaleDateString()}</div>
          <button onClick={startEditingHandler}>Edit</button>
          <button onClick={() => props.onRemoveExpense(props.id)}>Remove</button>
        </div>
      )}
    </li>
  );
};

export default ExpenseItem;
