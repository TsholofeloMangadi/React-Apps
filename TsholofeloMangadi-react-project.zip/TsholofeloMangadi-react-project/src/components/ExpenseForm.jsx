// components/ExpenseForm.js
import React, { useState } from 'react';
import './ExpenseForm.css'; 

const ExpenseForm = (props) => {
  const [enteredTitle, setEnteredTitle] = useState('');
  const [enteredAmount, setEnteredAmount] = useState('');
  const [enteredDate, setEnteredDate] = useState('');
  const [isIncome, setIsIncome] = useState(false);

  const titleChangeHandler = (event) => {
    setEnteredTitle(event.target.value);
  };

  const amountChangeHandler = (event) => {
    setEnteredAmount(event.target.value);
  };

  const dateChangeHandler = (event) => {
    setEnteredDate(event.target.value);
  };

  const incomeChangeHandler = (event) => {
    setIsIncome(event.target.checked);
  };

  const submitHandler = (event) => {
    event.preventDefault();

    const expenseData = {
      id: Math.random().toString(),
      title: enteredTitle,
      amount: +enteredAmount,
      date: new Date(enteredDate),
    };

    if (isIncome) {
      props.onAddIncome(expenseData);
    } else {
      props.onAddExpense(expenseData);
    }

    setEnteredTitle('');
    setEnteredAmount('');
    setEnteredDate('');
    setIsIncome(false);
  };

  return (
    <form onSubmit={submitHandler}>
      <div className="expense-form">
        <div>
          <label>Title</label>
          <input
            type="text"
            value={enteredTitle}
            onChange={titleChangeHandler}
          />
        </div>
        <div>
          <label>Amount</label>
          <input
            type="number"
            min="0.01"
            step="0.01"
            value={enteredAmount}
            onChange={amountChangeHandler}
          />
        </div>
        <div>
          <label>Date</label>
          <input
            type="date"
            value={enteredDate}
            onChange={dateChangeHandler}
          />
        </div>
        <div>
          <label class="container">
            <input type="checkbox" checked={isIncome} onChange={incomeChangeHandler} />
            <span class="checkmark"></span>
            Income
          </label>
        </div>
        <div>
          <button type="submit">Add {isIncome ? 'Income' : 'Expense'}</button>
        </div>
      </div>
    </form>
  );
};

export default ExpenseForm;
