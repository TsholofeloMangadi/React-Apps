// App.js
import React, { useState } from 'react';
import Expenses from './components/Expenses';
import ExpenseForm from './components/ExpenseForm';
import './App.css';

function App() {
  const [expenses, setExpenses] = useState([]);
  const [income, setIncome] = useState([]);

  const addExpenseHandler = (expense) => {
    setExpenses((prevExpenses) => [expense, ...prevExpenses]);
  };

  const removeExpenseHandler = (expenseId) => {
    setExpenses((prevExpenses) =>
      prevExpenses.filter((expense) => expense.id !== expenseId)
    );
  };

  const editExpenseHandler = (updatedExpense) => {
    setExpenses((prevExpenses) =>
      prevExpenses.map((expense) =>
        expense.id === updatedExpense.id ? updatedExpense : expense
      )
    );
  };

  const addIncomeHandler = (income) => {
    setIncome((prevIncome) => [income, ...prevIncome]);
  };

  const calculateBalance = () => {
    const totalIncome = income.reduce((acc, currentIncome) => acc + currentIncome.amount, 0);
    const totalExpenses = expenses.reduce((acc, currentExpense) => acc + currentExpense.amount, 0);
    return totalIncome - totalExpenses;
  };

  return (
    <div className="app">
      <h1>Expense Tracker</h1>

      <div className="balance">
        <h2>Balance</h2>
        <p>R{calculateBalance()}</p>
      </div>
      
      <ExpenseForm onAddExpense={addExpenseHandler} onAddIncome={addIncomeHandler} />
      <Expenses
        items={expenses}
        onRemoveExpense={removeExpenseHandler}
        onEditExpense={editExpenseHandler}
      />

    </div>
  );
}

export default App;
